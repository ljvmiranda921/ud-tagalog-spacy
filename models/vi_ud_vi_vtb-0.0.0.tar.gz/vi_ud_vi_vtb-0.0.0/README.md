| Feature | Description |
| --- | --- |
| **Name** | `vi_ud_vi_vtb` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.2.4,<3.3.0` |
| **Default Pipeline** | `tok2vec`, `tagger`, `morphologizer`, `parser` |
| **Components** | `tok2vec`, `tagger`, `morphologizer`, `parser` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (75 labels for 3 components)</summary>

| Component | Labels |
| --- | --- |
| **`tagger`** | `!`, `"`, `,`, `-`, `.`, `...`, `:`, `;`, `?`, `@`, `A`, `C`, `CC`, `E`, `I`, `L`, `LBKT`, `M`, `N`, `NP`, `Nb`, `Nc`, `Np`, `Nu`, `Ny`, `P`, `R`, `RBKT`, `T`, `V`, `VP`, `X`, `Y`, `Z` |
| **`morphologizer`** | `POS=NOUN`, `POS=ADP`, `POS=X\|Polarity=Neg`, `POS=VERB`, `POS=ADJ`, `POS=PUNCT`, `POS=X`, `POS=SCONJ`, `NumType=Card\|POS=NUM`, `POS=DET`, `POS=CCONJ`, `POS=PROPN`, `POS=AUX`, `POS=PART`, `POS=INTJ` |
| **`parser`** | `ROOT`, `advcl`, `advmod`, `amod`, `appos`, `aux`, `aux:pass`, `case`, `cc`, `ccomp`, `compound`, `conj`, `cop`, `csubj`, `dep`, `det`, `discourse`, `mark`, `nmod`, `nsubj`, `nummod`, `obj`, `obl`, `parataxis`, `punct`, `xcomp` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `TAG_ACC` | 84.93 |
| `POS_ACC` | 86.95 |
| `MORPH_ACC` | 99.75 |
| `DEP_UAS` | 54.34 |
| `DEP_LAS` | 43.82 |
| `SENTS_P` | 98.26 |
| `SENTS_R` | 99.00 |
| `SENTS_F` | 98.63 |
| `TOK2VEC_LOSS` | 2230752.97 |
| `TAGGER_LOSS` | 167629.47 |
| `MORPHOLOGIZER_LOSS` | 124496.02 |
| `PARSER_LOSS` | 688739.87 |