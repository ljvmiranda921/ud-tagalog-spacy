| Feature | Description |
| --- | --- |
| **Name** | `tl_ud_tl_trg` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.2.4,<3.3.0` |
| **Default Pipeline** | `tok2vec`, `tagger`, `morphologizer`, `parser` |
| **Components** | `tok2vec`, `tagger`, `morphologizer`, `parser` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (89 labels for 3 components)</summary>

| Component | Labels |
| --- | --- |
| **`tagger`** | `ADJ`, `ADP`, `ADV`, `AUX`, `DET`, `INTJ`, `NOUN`, `PART`, `PRON`, `PROPN`, `PUNCT`, `SCONJ`, `VERB` |
| **`morphologizer`** | `POS=NOUN`, `Case=Nom\|POS=ADP`, `Aspect=Perf\|Mood=Ind\|POS=VERB\|Voice=Act`, `Case=Gen\|POS=ADP`, `POS=PUNCT`, `Link=Yes\|POS=VERB\|Polarity=Neg`, `Case=Dat\|POS=ADP`, `Aspect=Prog\|Mood=Ind\|POS=VERB\|Voice=Lfoc`, `POS=ADP`, `Degree=Pos\|POS=ADJ\|PronType=Int`, `Case=Gen\|Number=Plur\|POS=PRON\|Person=3\|PronType=Prs`, `Aspect=Perf\|Mood=Ind\|POS=VERB\|Voice=Lfoc`, `Case=Gen\|Number=Sing\|POS=PRON\|Person=3\|PronType=Prs`, `Aspect=Imp\|Mood=Ind\|POS=VERB\|Voice=Act`, `Aspect=Prog\|Mood=Ind\|POS=VERB\|Voice=Bfoc`, `Degree=Pos\|POS=ADJ`, `Link=Yes\|POS=NOUN`, `Aspect=Perf\|Mood=Ind\|POS=VERB\|Voice=Ifoc`, `Gender=Masc\|POS=PROPN`, `Gender=Fem\|POS=PROPN`, `POS=ADV\|PronType=Dem`, `POS=SCONJ`, `Case=Nom\|Number=Sing\|POS=PRON\|Person=1\|PronType=Prs`, `Aspect=Hab\|POS=VERB\|Voice=Pass`, `Gender=Masc\|Link=Yes\|POS=PROPN`, `Aspect=Perf\|Mood=Ind\|POS=VERB\|Voice=Pass`, `Case=Nom\|Number=Sing\|POS=PRON\|Person=3\|PronType=Prs`, `Case=Nom\|Deixis=Prox\|Number=Sing\|POS=PRON\|PronType=Dem`, `Case=Gen\|Link=Yes\|Number=Sing\|POS=PRON\|Person=1\|PronType=Prs`, `POS=PROPN`, `POS=PART\|PartType=Int`, `Degree=Pos\|Link=Yes\|POS=ADJ`, `POS=VERB\|Polarity=Neg`, `Case=Gen\|Number=Sing\|POS=PRON\|Person=1\|PronType=Prs`, `POS=PRON\|PronType=Prs\|Reflex=Yes`, `Aspect=Perf\|Mood=Ind\|POS=VERB\|PronType=Int\|Voice=Pass`, `Case=Nom\|Number=Sing\|POS=PRON\|Person=2\|PronType=Prs`, `Aspect=Prog\|Mood=Ind\|POS=VERB\|Voice=Act`, `POS=PART\|PartType=Nfh`, `POS=ADV`, `POS=ADV\|PronType=Int`, `POS=PART\|Polarity=Neg`, `Aspect=Hab\|POS=VERB`, `Aspect=Prog\|Mood=Ind\|POS=VERB\|Voice=Pass`, `Number=Plur\|POS=DET\|PronType=Ind`, `POS=VERB\|Polarity=Pos`, `Link=Yes\|POS=PART\|PartType=Int`, `Aspect=Prosp\|Mood=Ind\|POS=VERB\|Voice=Act`, `Gender=Masc\|POS=NOUN`, `Case=Dat\|Link=Yes\|Number=Sing\|POS=PRON\|Person=3\|PronType=Prs`, `Case=Nom\|Number=Plur\|POS=PRON\|Person=3\|PronType=Prs`, `Aspect=Perf\|Mood=Ind\|POS=VERB\|PronType=Int\|Voice=Act`, `Gender=Fem\|POS=NOUN`, `POS=INTJ\|Polarity=Pos`, `POS=PART\|PartType=Des`, `POS=DET\|PronType=Tot`, `Gender=Masc\|POS=DET\|PronType=Emp`, `Aspect=Imp\|Mood=Pot\|POS=VERB\|Voice=Act`, `Mood=Imp\|POS=AUX\|Polarity=Neg`, `Case=Nom\|Link=Yes\|Number=Plur\|POS=PRON\|Person=2\|PronType=Prs`, `Case=Nom\|Link=Yes\|Number=Sing\|POS=PRON\|Person=3\|PronType=Prs`, `Aspect=Imp\|Mood=Ind\|POS=VERB\|Voice=Pass`, `Case=Nom\|POS=PRON\|PronType=Int`, `Deixis=Remt\|POS=ADV\|PronType=Dem`, `Link=Yes\|POS=VERB\|Polarity=Pos`, `Mood=Imp\|POS=VERB\|Voice=Act`, `Case=Dat\|Number=Sing\|POS=PRON\|Person=3\|PronType=Prs`, `Mood=Imp\|POS=VERB\|Voice=Lfoc`, `Case=Gen\|Number=Sing\|POS=PRON\|Person=2\|PronType=Prs`, `Degree=Pos\|Gender=Fem\|POS=ADJ`, `Mood=Imp\|POS=VERB\|Voice=Pass` |
| **`parser`** | `ROOT`, `case`, `dep`, `nsubj`, `punct` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `TAG_ACC` | 93.24 |
| `POS_ACC` | 92.57 |
| `MORPH_ACC` | 85.14 |
| `DEP_UAS` | 87.97 |
| `DEP_LAS` | 55.60 |
| `SENTS_P` | 92.59 |
| `SENTS_R` | 96.15 |
| `SENTS_F` | 94.34 |
| `TOK2VEC_LOSS` | 25579.13 |
| `TAGGER_LOSS` | 167333.46 |
| `MORPHOLOGIZER_LOSS` | 284023.37 |
| `PARSER_LOSS` | 326939.35 |