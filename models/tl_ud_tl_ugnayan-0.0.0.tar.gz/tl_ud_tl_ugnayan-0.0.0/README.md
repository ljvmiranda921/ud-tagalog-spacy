| Feature | Description |
| --- | --- |
| **Name** | `tl_ud_tl_ugnayan` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.2.4,<3.3.0` |
| **Default Pipeline** | `tok2vec`, `tagger`, `morphologizer`, `parser` |
| **Components** | `tok2vec`, `tagger`, `morphologizer`, `parser` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (45 labels for 3 components)</summary>

| Component | Labels |
| --- | --- |
| **`tagger`** | `ADJ`, `ADJ_PART`, `ADP`, `ADV`, `ADV_PART`, `CCONJ`, `DET`, `DET_ADP`, `DET_PART`, `INTJ`, `NOUN`, `NOUN_PART`, `NUM`, `NUM_PART`, `PART`, `PRON`, `PRON_PART`, `PROPN`, `PUNCT`, `SCONJ`, `VERB`, `VERB_PART` |
| **`morphologizer`** | `POS=VERB`, `POS=ADV`, `POS=ADP`, `POS=PROPN`, `POS=NOUN`, `POS=DET`, `POS=PUNCT`, `POS=PART`, `POS=PRON`, `POS=NUM`, `POS=CCONJ`, `POS=SCONJ`, `POS=ADJ`, `POS=INTJ` |
| **`parser`** | `ROOT`, `amod`, `case`, `dep`, `nmod`, `nsubj`, `obj`, `obl`, `punct` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `TAG_ACC` | 84.73 |
| `POS_ACC` | 86.21 |
| `MORPH_ACC` | 99.01 |
| `MORPH_PER_FEAT` | 0.00 |
| `DEP_UAS` | 69.27 |
| `DEP_LAS` | 44.13 |
| `SENTS_P` | 90.00 |
| `SENTS_R` | 94.74 |
| `SENTS_F` | 92.31 |
| `TOK2VEC_LOSS` | 55726.55 |
| `TAGGER_LOSS` | 1224.32 |
| `MORPHOLOGIZER_LOSS` | 964.65 |
| `PARSER_LOSS` | 41597.92 |